<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class WordPressService
{
    protected string $baseUrl;

    public function __construct()
    {
        $this->baseUrl = rtrim(env('WORDPRESS_API_URL', 'http://localhost:8000/wp-json'), '/');
    }

    public function getPosts(int $perPage = 10, int $page = 1): array
    {
        $cacheKey = "wordpress_posts_page_{$page}_limit_{$perPage}";

        $posts = Cache::remember($cacheKey, 1800, function () use ($perPage, $page) {
            try {
                $response = Http::timeout(5)->get("{$this->baseUrl}/wp/v2/posts", [
                    'per_page' => $perPage,
                    'page' => $page,
                    '_embed' => 1, // Embeds featured media, author, etc.
                ]);

                if ($response->successful()) {
                    return $response->json();
                }

                Log::warning("WordPress REST API returned status " . $response->status());
            } catch (\Exception $e) {
                Log::error("Failed to connect to WordPress API: " . $e->getMessage());
            }

            // Fallback mock posts if the API is offline
            return $this->getMockPosts();
        });

        return is_array($posts) ? $posts : $this->getMockPosts();
    }

    /**
     * Get single post detail from WordPress REST API.
     */
    public function getPost(int $id): ?array
    {
        $cacheKey = "wordpress_post_{$id}";

        $post = Cache::remember($cacheKey, 1800, function () use ($id) {
            try {
                $response = Http::timeout(5)->get("{$this->baseUrl}/wp/v2/posts/{$id}", [
                    '_embed' => 1,
                ]);

                if ($response->successful()) {
                    return $response->json();
                }

                Log::warning("WordPress REST API for post ID {$id} returned status " . $response->status());
            } catch (\Exception $e) {
                Log::error("Failed to connect to WordPress API for post ID {$id}: " . $e->getMessage());
            }

            // Fallback single post search in mock posts
            return $this->getMockPostById($id);
        });

        return is_array($post) ? $post : $this->getMockPostById($id);
    }

    /**
     * Fallback mock posts for offline development.
     */
    protected function getMockPosts(): array
    {
        return [
            [
                'id' => 101,
                'title' => ['rendered' => '5 Langkah Strategis Lolos Beasiswa LPDP 2026'],
                'excerpt' => ['rendered' => 'Ingin lolos beasiswa LPDP? Pelajari strategi jitu menyusun esai kontribusi dan menghadapi wawancara dari alumni sukses.'],
                'content' => [
                    'rendered' => '<p>Beasiswa Lembaga Pengelola Dana Pendidikan (LPDP) adalah salah satu beasiswa paling populer dan bergengsi bagi mahasiswa Indonesia yang ingin melanjutkan studi S2 atau S3. Proses seleksi LPDP dikenal sangat kompetitif dan ketat. Untuk membantu Anda bersiap, berikut adalah 5 langkah strategis yang terbukti meloloskan banyak awardee:</p><h3>1. Pahami Visi dan Karakter Calon Penerima Beasiswa LPDP</h3><p>LPDP mencari calon pemimpin masa depan yang memiliki komitmen kuat untuk kembali dan berkontribusi bagi Indonesia. Seluruh dokumen dan jawaban Anda selama wawancara harus sejalan dengan visi ini. Identifikasi kontribusi konkret apa yang bisa Anda berikan kepada masyarakat atau sektor industri Anda sekembalinya dari studi.</p><h3>2. Tulis Esai Kontribusi dengan Struktur yang Kuat</h3><p>Esai kontribusi bukan sekadar curahan hati atau daftar riwayat hidup. Buatlah esai yang terstruktur dengan memuat tiga poin utama:</p><ul><li><strong>Masalah Nyata:</strong> Deskripsikan masalah mendesak di Indonesia yang relevan dengan bidang keahlian Anda.</li><li><strong>Rencana Solusi:</strong> Jelaskan bagaimana studi yang Anda pilih akan membantu menyelesaikan masalah tersebut.</li><li><strong>Kontribusi Riil:</strong> Jelaskan peran konkret yang akan Anda ambil setelah lulus, baik jangka pendek maupun jangka panjang.</li></ul><h3>3. Dapatkan Surat Rekomendasi yang Kredibel</h3><p>Surat rekomendasi sebaiknya berasal dari dosen pembimbing akademis atau atasan langsung di tempat kerja yang benar-benar mengenal kompetensi dan karakter Anda. Mintalah surat rekomendasi jauh-jauh hari dan berikan mereka draf esai atau CV Anda agar rekomendasi yang ditulis bisa lebih spesifik dan berbobot.</p><h3>4. Lakukan Riset Universitas dan Program Studi Tujuan Secara Mendalam</h3><p>Jangan memilih universitas hanya berdasarkan reputasi global atau peringkat QS World saja. Pelajari kurikulum mata kuliah, daftar laboratorium penelitian, dan keahlian dosen pembimbing di universitas tersebut. Anda harus bisa menjelaskan mengapa universitas tersebut adalah tempat terbaik untuk mendukung rencana kontribusi Anda.</p><h3>5. Persiapkan Wawancara dengan Simulasi (Mock Interview)</h3><p>Wawancara adalah penentu akhir kelulusan Anda. Latihlah cara berbicara, bahasa tubuh, dan cara menjawab pertanyaan sulit seperti kelemahan diri atau rencana kontribusi yang kurang realistis. Lakukan simulasi berkali-kali bersama alumni LPDP atau rekan sejawat untuk mendapatkan umpan balik yang konstruktif.</p>'
                ],
                'date' => '2026-06-05T10:00:00',
                '_embedded' => [
                    'author' => [['name' => 'Budi Santoso (LPDP Awardee @ UCL)']],
                    'wp:featuredmedia' => [[
                        'source_url' => 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?q=80&w=1200&auto=format&fit=crop'
                    ]]
                ]
            ],
            [
                'id' => 102,
                'title' => ['rendered' => 'Panduan Menulis Motivation Letter yang Menarik Perhatian Komite'],
                'excerpt' => ['rendered' => 'Motivation letter adalah penentu kelulusan administrasi Anda. Simak struktur penulisan yang baik dan contoh praktisnya di sini.'],
                'content' => [
                    'rendered' => '<p>Motivation letter adalah salah satu dokumen paling krusial dalam aplikasi beasiswa. Dokumen satu halaman ini menjadi kesempatan pertama Anda untuk berkomunikasi langsung dengan komite seleksi dan meyakinkan mereka bahwa Anda adalah kandidat terbaik. Berikut adalah panduan langkah demi langkah menulis motivation letter yang memukau:</p><h3>1. Bagian Pendahuluan: Tuliskan Kalimat Pembuka (Hook) yang Menarik</h3><p>Hindari pembukaan klise seperti <em>"Nama saya adalah X dan saya ingin melamar beasiswa Y..."</em>. Cobalah mulai dengan cerita singkat tentang momen penting yang memicu ketertarikan Anda pada bidang studi tersebut. Misalnya, pengalaman kerja lapangan atau proyek penelitian yang membuka mata Anda terhadap tantangan di sektor tersebut.</p><h3>2. Bagian Isi: Hubungkan Latar Belakang Akademis dengan Tujuan Studi</h3><p>Pada paragraf berikutnya, jelaskan pencapaian akademis dan profesional Anda yang relevan. Ceritakan bagaimana latar belakang tersebut mempersiapkan Anda untuk mengambil program studi tujuan. Jelaskan juga mata kuliah spesifik di universitas target yang sangat ingin Anda pelajari dan bagaimana hal tersebut berkaitan langsung dengan karier impian Anda.</p><h3>3. Tunjukkan Mengapa Anda Memilih Universitas dan Negara Tersebut</h3><p>Tunjukkan bahwa Anda telah melakukan riset mendalam. Mengapa memilih Jerman dibanding Inggris? Mengapa memilih program Master di universitas ini bukan universitas lain? Hubungkan keunggulan fasilitas, budaya akademik, atau fokus riset universitas tersebut dengan rencana masa depan Anda.</p><h3>4. Bagian Penutup: Akhiri dengan Pernyataan Kontribusi yang Kuat</h3><p>Tutup surat motivasi Anda dengan merangkum kembali komitmen Anda. Jelaskan secara singkat bagaimana beasiswa ini akan bertindak sebagai batu loncatan yang membantu Anda memberikan dampak positif bagi komunitas, organisasi, atau negara asal Anda setelah lulus studi.</p>'
                ],
                'date' => '2026-06-04T14:30:00',
                '_embedded' => [
                    'author' => [['name' => 'Siti Aminah (Chevening Awardee @ Oxford)']],
                    'wp:featuredmedia' => [[
                        'source_url' => 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?q=80&w=1200&auto=format&fit=crop'
                    ]]
                ]
            ],
            [
                'id' => 103,
                'title' => ['rendered' => 'IELTS vs TOEFL iBT: Perbedaan Detail & Tips Memilih Tes Bahasa'],
                'excerpt' => ['rendered' => 'Bingung memilih tes kecakapan bahasa Inggris untuk beasiswa? Cari tahu perbedaan format, sistem penilaian, dan kecocokannya di sini.'],
                'content' => [
                    'rendered' => '<p>Sertifikat kecakapan bahasa Inggris adalah persyaratan mutlak untuk sebagian besar beasiswa dalam dan luar negeri. Dua jenis tes yang paling populer dan diterima secara global adalah IELTS (International English Language Testing System) dan TOEFL iBT (Test of English as a Foreign Language internet-Based Test). Simak perbandingan mendalam berikut untuk menentukan pilihan Anda:</p><h3>1. Format dan Metode Pelaksanaan Tes</h3><p>Perbedaan terbesar terletak pada bagaimana tes diselenggarakan:</p><ul><li><strong>IELTS:</strong> Tersedia dalam format berbasis komputer dan kertas. Pada bagian Speaking, Anda akan melakukan wawancara tatap muka secara langsung dengan seorang penguji penutur asli (native speaker).</li><li><strong>TOEFL iBT:</strong> Seluruh tes dilakukan secara komputerisasi. Bahkan pada sesi Speaking, Anda akan berbicara menggunakan mikrofon dan rekaman suara Anda akan dinilai oleh sistem kombinasi AI dan penguji manusia.</li></ul><h3>2. Struktur Sesi Ujian</h3><p>Kedua tes menguji empat keterampilan utama, namun dengan pendekatan yang sedikit berbeda:</p><ul><li><strong>Listening:</strong> IELTS menggunakan aksen bahasa Inggris yang beragam (British, Australian, American) dengan tipe soal isian singkat dan pilihan ganda. TOEFL didominasi aksen American dengan tipe soal pilihan ganda berbasis rekaman kuliah akademis.</li><li><strong>Writing:</strong> IELTS mengharuskan Anda mendeskripsikan grafik/tabel di tugas pertama dan menulis esai argumentatif di tugas kedua. TOEFL menguji kemampuan integrasi (membaca, mendengarkan, lalu menulis rangkuman) dan esai diskusi akademis.</li></ul><h3>3. Sistem Penilaian (Skor)</h3><p>Sistem skor keduanya sangat berbeda. IELTS dinilai menggunakan skala Band Score dari 1.0 hingga 9.0 (dengan kenaikan per 0.5). Sementara itu, TOEFL iBT dinilai dengan rentang skor total dari 0 hingga 120 (masing-masing dari 4 sesi bernilai maksimum 30 poin).</p><h3>4. Negara dan Beasiswa Mana yang Harus Dipilih?</h3><p>Secara umum, IELTS sangat populer di Inggris, Australia, Selandia Baru, Kanada, dan Eropa. TOEFL iBT sangat dominan di Amerika Serikat. Namun saat ini, hampir semua universitas top dunia menerima keduanya. Pilihlah tes yang sesuai dengan kenyamanan Anda: apakah Anda lebih suka berbicara langsung dengan manusia (IELTS) atau berinteraksi penuh dengan komputer (TOEFL).</p>'
                ],
                'date' => '2026-06-01T09:15:00',
                '_embedded' => [
                    'author' => [['name' => 'Andi Wijaya (IELTS Trainer & Consultant)']],
                    'wp:featuredmedia' => [[
                        'source_url' => 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?q=80&w=1200&auto=format&fit=crop'
                    ]]
                ]
            ],
            [
                'id' => 104,
                'title' => ['rendered' => 'Cara Menghubungi Calon Promotor Akademik di Luar Negeri'],
                'excerpt' => ['rendered' => 'Untuk melamar beasiswa riset S2/S3, Anda membutuhkan persetujuan profesor. Pelajari etika menulis email dingin (cold email) agar direspon.'],
                'content' => [
                    'rendered' => '<p>Bagi pelamar beasiswa jalur riset (Master by Research atau PhD), mendapatkan supervisor atau promotor akademik adalah salah satu prasyarat wajib. Menghubungi profesor luar negeri yang belum pernah Anda kenal (disebut cold emailing) membutuhkan strategi khusus agar email Anda dibaca dan dibalas. Berikut panduannya:</p><h3>1. Lakukan Riset Mendalam Mengenai Profil Profesor</h3><p>Jangan mengirim email massal yang sama ke banyak profesor. Cari profesor yang memiliki minat penelitian yang selaras dengan proposal tesis atau disertasi Anda. Baca setidaknya 2 atau 3 jurnal ilmiah terbaru yang dipublikasikan oleh profesor tersebut agar Anda memahami fokus riset terkininya.</p><h3>2. Gunakan Subjek Email yang Jelas dan Profesional</h3><p>Subjek email harus langsung menjelaskan maksud Anda. Gunakan format yang ringkas seperti:<br><strong>"Inquiry on PhD Supervision - [Nama Beasiswa / Bidang Riset]"</strong> atau <strong>"Prospective Research Student: [Nama Anda]"</strong>. Hal ini meminimalkan risiko email Anda masuk ke folder spam atau diabaikan karena dikira iklan.</p><h3>3. Struktur Isi Email yang Ringkas dan Padat</h3><p>Tulis email dalam bahasa Inggris yang formal dengan bagian-bagian berikut:</p><ul><li><strong>Salam & Pengenalan:</strong> Perkenalkan diri, latar belakang pendidikan, dan IPK Anda secara singkat.</li><li><strong>Ketertarikan Riset:</strong> Jelaskan mengapa Anda tertarik pada riset beliau, sebutkan jurnal beliau yang Anda baca, dan hubungkan dengan rencana riset Anda.</li><li><strong>Rencana Pendanaan:</strong> Nyatakan bahwa Anda sedang atau akan melamar beasiswa (misalnya LPDP, MEXT, atau AAS) untuk mendanai studi Anda secara penuh.</li></ul><h3>4. Lampirkan CV Akademik dan Ringkasan Proposal Riset</h3><p>Lampirkan CV akademik (maksimal 2 halaman) yang menonjolkan IPK, publikasi ilmiah, dan pengalaman riset. Sertakan juga ringkasan draf proposal penelitian (Research Proposal) sebanyak 1-2 halaman saja. Jangan melampirkan berkas berukuran besar lainnya kecuali diminta.</p>'
                ],
                'date' => '2026-05-28T11:20:00',
                '_embedded' => [
                    'author' => [['name' => 'Dr. Ahmad Fauzi (Research Fellow @ Tokyo Tech)']],
                    'wp:featuredmedia' => [[
                        'source_url' => 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?q=80&w=1200&auto=format&fit=crop'
                    ]]
                ]
            ],
            [
                'id' => 105,
                'title' => ['rendered' => 'Cara Menjawab Pertanyaan Wawancara Beasiswa dengan Metode STAR'],
                'excerpt' => ['rendered' => 'Pelajari cara menyusun jawaban wawancara beasiswa secara sistematis, logis, dan profesional menggunakan kerangka kerja STAR.'],
                'content' => [
                    'rendered' => '<p>Tahap wawancara sering kali menjadi bagian yang paling menegangkan dalam seleksi beasiswa. Salah satu kesalahan umum kandidat adalah memberikan jawaban yang terlalu bertele-tele atau tidak fokus. Untuk mengatasinya, Anda bisa menggunakan metode STAR. Ini adalah kerangka kerja yang sangat efektif untuk menjawab pertanyaan berbasis perilaku (behavioral questions), seperti menceritakan pengalaman kepemimpinan atau cara mengatasi konflik.</p><h3>Mengenal Komponen Metode STAR</h3><p>STAR adalah singkatan dari empat elemen utama:</p><ul><li><strong>Situation (Situasi):</strong> Deskripsikan konteks atau latar belakang dari kejadian yang ingin Anda ceritakan secara singkat namun jelas.</li><li><strong>Task (Tugas):</strong> Jelaskan tanggung jawab atau tantangan utama yang harus diselesaikan dalam situasi tersebut.</li><li><strong>Action (Tindakan):</strong> Terangkan secara detail tindakan nyata apa yang Anda ambil untuk mengatasi masalah. Fokuskan pada peran Anda sendiri, bukan kelompok.</li><li><strong>Result (Hasil):</strong> Bagikan hasil akhir dari tindakan Anda. Sajikan data kuantitatif jika memungkinkan (misalnya: meningkatkan efisiensi sebesar 20%, menghemat waktu pendaftaran, dsb).</li></ul><h3>Contoh Penerapan Metode STAR</h3><p>Berikut adalah simulasi jawaban atas pertanyaan: <em>"Ceritakan momen ketika Anda berhasil menunjukkan kemampuan kepemimpinan Anda."</em></p><p><strong>[Situation]</strong> "Saat semester 6 kuliah S1, saya ditunjuk menjadi ketua panitia seminar nasional dengan target 500 peserta."</p><p><strong>[Task]</strong> "Tiga minggu sebelum acara dimulai, jumlah pendaftar baru mencapai 150 orang karena promosi offline kami kurang efektif."</p><p><strong>[Action]</strong> "Saya segera mereorganisasi tim humas dan mengalihkan fokus ke kampanye digital berbayar serta bekerja sama dengan 10 media partner kampus. Saya juga mengadakan kuis interaktif di Instagram untuk menarik audiens."</p><p><strong>[Result]</strong> "Hasilnya, dalam waktu dua minggu, kami berhasil mendaftarkan 580 peserta (melebihi target awal sebesar 16%) dan acara berjalan sukses tanpa hambatan teknis."</p>'
                ],
                'date' => '2026-05-25T15:45:00',
                '_embedded' => [
                    'author' => [['name' => 'Diana Putri (AAS Awardee @ Melbourne Uni)']],
                    'wp:featuredmedia' => [[
                        'source_url' => 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=1200&auto=format&fit=crop'
                    ]]
                ]
            ],
            [
                'id' => 106,
                'title' => ['rendered' => 'Timeline Persiapan Beasiswa Luar Negeri Sejak 1 Tahun Sebelum Apply'],
                'excerpt' => ['rendered' => 'Persiapan yang terburu-buru adalah penyebab utama kegagalan beasiswa. Simak timeline aksi bulanan terbaik untuk kelolosan Anda.'],
                'content' => [
                    'rendered' => '<p>Mempersiapkan pendaftaran beasiswa dan universitas luar negeri bukanlah proses instan. Banyak dokumen seperti sertifikat bahasa, surat rekomendasi, dan esai memerlukan waktu berbulan-bulan untuk dipoles hingga matang. Untuk memaksimalkan peluang lolos, berikut adalah timeline ideal 12 bulan yang bisa Anda ikuti:</p><h3>Bulan 1 - 3: Riset Mendalam dan Menentukan Target</h3><p>Mulailah dengan membuat daftar target beasiswa (seperti LPDP, AAS, Chevening, MEXT) beserta persyaratannya. Tentukan pula 3 universitas dan jurusan tujuan. Di tahap ini, lakukan penilaian mandiri terhadap kemampuan bahasa Inggris Anda dengan mengikuti tes simulasi (prediction test).</p><h3>Bulan 4 - 6: Persiapan dan Tes Kecakapan Bahasa Inggris</h3><p>Gunakan waktu ini untuk belajar secara intensif untuk IELTS atau TOEFL. Jadwalkan tes resmi pada bulan ke-6. Mengambil tes lebih awal memberi Anda waktu cadangan untuk tes ulang seandainya skor pertama belum memenuhi syarat minimum universitas tujuan Anda.</p><h3>Bulan 7 - 9: Pembuatan Esai dan Menghubungi Penulis Rekomendasi</h3><p>Mulailah menyusun draf pertama motivation letter, esai kontribusi, atau proposal penelitian. Tulis beberapa versi dan mintalah koreksi dari mentor atau alumni. Secara bersamaan, hubungi dosen atau atasan Anda untuk meminta kesediaan mereka menulis surat rekomendasi.</p><h3>Bulan 10 - 11: Pendaftaran Universitas & Penerjemahan Dokumen</h3><p>Dapatkan Letter of Acceptance (LoA) dari universitas pilihan Anda dengan mendaftar langsung ke portal admisi kampus. Pastikan juga semua ijazah, transkrip nilai, dan dokumen pendukung lainnya telah diterjemahkan oleh penerjemah tersumpah (sworn translator).</p><h3>Bulan 12: Pengajuan Aplikasi Beasiswa & Latihan Wawancara</h3><p>Unggah seluruh dokumen yang telah dipersiapkan dengan teliti ke portal beasiswa tujuan. Jangan mengirimkan aplikasi mepet dengan batas waktu (deadline) untuk menghindari server lambat. Setelah submit, segera lakukan latihan wawancara secara intensif.</p>'
                ],
                'date' => '2026-05-20T09:00:00',
                '_embedded' => [
                    'author' => [['name' => 'Rian Kurnia (MEXT Awardee @ Kyoto Uni)']],
                    'wp:featuredmedia' => [[
                        'source_url' => 'https://images.unsplash.com/photo-1506784983877-45594efa4cbe?q=80&w=1200&auto=format&fit=crop'
                    ]]
                ]
            ]
        ];
    }

    /**
     * Find fallback single mock post by ID.
     */
    protected function getMockPostById(int $id): ?array
    {
        foreach ($this->getMockPosts() as $post) {
            if ($post['id'] === $id) {
                return $post;
            }
        }
        return null;
    }
}
